# TPPOO2
Project in 3IF by Yohan Gracia and Zifan Yao
## Liste des classes
Trajet, TrajetSimple, TrajetCompose, Parcours, Catalogue.
## Trucs à faire
Tout hehexd
